# RU-Rural
Sistema Inteligente de Monitoramento da Fila do RU da UFRPE
